#!/bin/sh

set -e

"$(dirname "$0")/npm_install.sh" yaml-language-server yaml-language-server
