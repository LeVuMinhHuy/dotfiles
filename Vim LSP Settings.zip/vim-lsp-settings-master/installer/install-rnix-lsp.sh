#!/usr/bin/env bash

set -e

nix-env -i -f "https://github.com/nix-community/rnix-lsp/archive/master.tar.gz"
