#!/usr/bin/env bash

set -e

nix-env -f -iA nixpkgs.nil
