#!/bin/sh

set -e

"$(dirname "$0")/npm_install.sh" vscode-css-language-server vscode-langservers-extracted
