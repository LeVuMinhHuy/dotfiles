#!/bin/sh

set -e

ros install cxxxr/lem cxxxr/cl-lsp
