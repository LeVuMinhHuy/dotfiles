#!/usr/bin/env bash

set -e

nix-env -i -f "https://github.com/nix-community/nixd/archive/master.tar.gz"
